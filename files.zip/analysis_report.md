# 📊 Sales Data Analysis Report

> **Generated:** 25 March 2026, 20:05  
> **Data Range:** 01 Jan 2023 – 31 Dec 2024  
> **Pipeline:** Python (pandas) → SQLite → Power BI

---

## 🔢 Key Performance Indicators

| Metric | Value |
|--------|-------|
| Total Revenue         | $2,271,994.26 |
| Total Profit          | $795,719.03 |
| Avg Profit Margin     | 34.86% |
| Total Transactions    | 1,649 |
| Avg Order Value       | $1,377.80 |
| Total Units Sold      | 15,346 |

---

## 📅 Monthly Revenue Trend

![Monthly Revenue Trend](chart_revenue_trend.png)

|   Year | Month     | Revenue     | Profit     | Margin %   |
|-------:|:----------|:------------|:-----------|:-----------|
|   2023 | January   | $81,242.94  | $28,475.47 | 35.20%     |
|   2023 | February  | $97,075.38  | $32,827.91 | 34.47%     |
|   2023 | March     | $92,680.00  | $33,974.18 | 35.68%     |
|   2023 | April     | $108,507.74 | $37,904.83 | 35.17%     |
|   2023 | May       | $103,848.75 | $35,937.61 | 34.10%     |
|   2023 | June      | $98,813.01  | $34,142.25 | 35.18%     |
|   2023 | July      | $94,285.84  | $32,942.46 | 34.55%     |
|   2023 | August    | $93,244.58  | $31,651.45 | 34.68%     |
|   2023 | September | $98,850.34  | $33,954.86 | 34.25%     |
|   2023 | October   | $89,773.12  | $32,883.29 | 35.18%     |
|   2023 | November  | $86,520.76  | $29,275.67 | 35.16%     |
|   2023 | December  | $62,775.81  | $22,442.39 | 34.84%     |
|   2024 | January   | $106,763.43 | $37,780.45 | 34.52%     |
|   2024 | February  | $102,160.69 | $35,483.48 | 34.34%     |
|   2024 | March     | $73,138.51  | $26,360.44 | 34.96%     |
|   2024 | April     | $89,581.39  | $30,378.20 | 34.80%     |
|   2024 | May       | $106,803.43 | $38,309.47 | 35.51%     |
|   2024 | June      | $78,956.46  | $27,414.63 | 35.79%     |
|   2024 | July      | $95,364.22  | $34,085.86 | 34.39%     |
|   2024 | August    | $131,324.51 | $45,203.88 | 33.98%     |
|   2024 | September | $91,070.04  | $31,201.00 | 34.47%     |
|   2024 | October   | $108,623.63 | $37,568.65 | 35.14%     |
|   2024 | November  | $85,364.20  | $31,806.61 | 35.68%     |
|   2024 | December  | $95,225.48  | $33,713.99 | 34.99%     |

---

## 🏆 Top 5 Products by Revenue

![Top Products](chart_top_products.png)

| Product       | Category    |   Units | Revenue     | Margin %   |
|:--------------|:------------|--------:|:------------|:-----------|
| Office Chair  | Furniture   |    1796 | $566,491.38 | 34.87%     |
| Monitor 27"   | Electronics |    1135 | $467,853.80 | 34.89%     |
| Standing Desk | Furniture   |     506 | $319,906.05 | 33.73%     |
| Headset Pro   | Electronics |    1813 | $299,499.29 | 33.76%     |
| Keyboard MX   | Accessories |    1860 | $206,366.35 | 35.37%     |

---

## 🌍 Regional Performance

![Regional](chart_regional.png)

| Region   |   Transactions | Revenue     | Profit      | Share %   |
|:---------|---------------:|:------------|:------------|:----------|
| West     |            331 | $524,939.97 | $186,576.71 | 23.10%    |
| Central  |            371 | $481,171.66 | $169,157.10 | 21.18%    |
| East     |            336 | $457,798.12 | $159,447.96 | 20.15%    |
| South    |            313 | $409,164.43 | $143,487.24 | 18.01%    |
| North    |            298 | $398,920.08 | $137,050.02 | 17.56%    |

---

## 📡 Sales Channel Mix

![Channel Mix](chart_channel_mix.png)

| Channel      |   Transactions | Revenue     | Avg Discount   | Share %   |
|:-------------|---------------:|:------------|:---------------|:----------|
| Direct Sales |            473 | $658,596.81 | 6.87%          | 28.99%    |
| In-Store     |            402 | $540,730.50 | 7.49%          | 23.80%    |
| Online       |            404 | $538,127.33 | 6.87%          | 23.69%    |
| Partner      |            370 | $534,539.62 | 7.91%          | 23.53%    |

---

## 🥇 Top 5 Sales Representatives

| Sales Rep   |   Transactions | Revenue     | Profit     | Margin %   |   Rank |
|:------------|---------------:|:------------|:-----------|:-----------|-------:|
| Rep_15      |            130 | $185,569.09 | $65,258.37 | 35.11%     |      1 |
| Rep_11      |             84 | $139,841.01 | $50,175.80 | 35.62%     |      2 |
| Rep_07      |             83 | $134,707.47 | $47,779.73 | 35.01%     |      3 |
| Rep_05      |             94 | $129,352.97 | $43,974.11 | 33.59%     |      4 |
| Rep_10      |             76 | $122,111.65 | $42,345.05 | 34.01%     |      5 |

---

## 📌 Power BI Integration

The file `output/powerbi_export.csv` contains the fully denormalised flat table.
Import it into Power BI Desktop as a CSV source and connect the following recommended visuals:

| Visual | Fields |
|--------|--------|
| Line Chart       | date → revenue, profit |
| Bar Chart        | product → total_revenue |
| Map              | region → revenue |
| Donut Chart      | channel → revenue_share_pct |
| Matrix           | sales_rep × category → revenue |
| KPI Cards        | total_revenue, avg_margin_pct, avg_order_value |

---

*Report generated by the Python & SQL Data Analysis Pipeline.*